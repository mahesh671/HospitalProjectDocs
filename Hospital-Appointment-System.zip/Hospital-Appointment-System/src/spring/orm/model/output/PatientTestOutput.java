package spring.orm.model.output;

import spring.orm.model.PatientDiagnonisticReports;
import spring.orm.model.testModel;

public class PatientTestOutput {

	// test table
	private int test_id;
	private String test_name;
	private String test_method;
	private int test_price;
	private String dgdr_path; // pdreports table

	public String getDgdr_path() {
		return dgdr_path;
	}

	public void setDgdr_path(String dgdr_path) {
		this.dgdr_path = dgdr_path;
	}

	public int getTest_id() {
		return test_id;
	}

	public void setTest_id(int test_id) {
		this.test_id = test_id;
	}

	public String getTest_name() {
		return test_name;
	}

	public void setTest_name(String test_name) {
		this.test_name = test_name;
	}

	public String getTest_method() {
		return test_method;
	}

	public void setTest_method(String test_method) {
		this.test_method = test_method;
	}

	public int getTest_price() {
		return test_price;
	}

	public void setTest_price(int test_price) {
		this.test_price = test_price;
	}

	public void settest(testModel t) {
		// TODO Auto-generated method stub
		this.test_id = t.getTest_id();
		this.test_name = t.getTest_name();
		this.test_method = t.getTest_method();
		this.test_price = t.getTest_price();
	}

	public void setpdreports(PatientDiagnonisticReports pd) {
		this.dgdr_path = pd.getDgdr_path();
	}

	public PatientTestOutput(testModel t, PatientDiagnonisticReports pd) {
		super();
		this.test_id = t.getTest_id();
		this.test_name = t.getTest_name();
		this.test_method = t.getTest_method();
		this.test_price = t.getTest_price();
		this.dgdr_path = pd.getDgdr_path();
	}

	@Override
	public String toString() {
		return "PatientTestOutput [test_id=" + test_id + ", test_name=" + test_name + ", test_method=" + test_method
				+ ", test_price=" + test_price + ", dgdr_path=" + dgdr_path + "]";
	}

	public PatientTestOutput(int test_id, String test_name, String test_method, int test_price, String dgdr_path) {
		super();
		this.test_id = test_id;
		this.test_name = test_name;
		this.test_method = test_method;
		this.test_price = test_price;
		this.dgdr_path = dgdr_path;
	}

}