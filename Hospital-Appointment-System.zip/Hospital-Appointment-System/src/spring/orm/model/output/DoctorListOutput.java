package spring.orm.model.output;

public class DoctorListOutput {
	private int doctId;
	private String doctName;
	private String weekdays;
	
	
	public String getWeekdays() {
		return weekdays;
	}
	public void setWeekdays(String weekdays) {
		this.weekdays = weekdays;
	}
	public int getDoctId() {
		return doctId;
	}
	public void setDoctId(int doctId) {
		this.doctId = doctId;
	}
	public String getDoctName() {
		return doctName;
	}
	public void setDoctName(String doctName) {
		this.doctName = doctName;
	}
	public DoctorListOutput(int doctId, String doctName,String weekdays) {
		super();
		this.doctId = doctId;
		this.doctName = doctName;
		this.weekdays=weekdays;
	}
	public DoctorListOutput() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
