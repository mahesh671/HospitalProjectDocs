package spring.orm.model.output;

import java.util.Base64;

public class PrescriptionOutputmodel {

	private String patn_parameter;

	private String patn_pargroup;

	private String patn_value;
	private String patn_prescription;

	@Override
	public String toString() {
		return "PrescriptionOutputmodel [patn_parameter=" + patn_parameter + ", patn_pargroup=" + patn_pargroup
				+ ", patn_value=" + patn_value + ", patn_prescription=" + patn_prescription + "]";
	}

	public String getPatn_parameter() {
		return patn_parameter;
	}

	public void setPatn_parameter(String patn_parameter) {
		this.patn_parameter = patn_parameter;
	}

	public String getPatn_pargroup() {
		return patn_pargroup;
	}

	public void setPatn_pargroup(String patn_pargroup) {
		this.patn_pargroup = patn_pargroup;
	}

	public String getPatn_value() {
		return patn_value;
	}

	public void setPatn_value(String patn_value) {
		this.patn_value = patn_value;
	}

	public String getPatn_prescription() {
		return patn_prescription;
	}

	public void setPatn_prescription(byte[] patn_prescription) {
		this.patn_prescription = Base64.getEncoder().encodeToString(patn_prescription);
	}

	public PrescriptionOutputmodel(String patn_parameter, String patn_pargroup, String patn_value,
			byte[] patn_prescription) {
		this.patn_parameter = patn_parameter;
		this.patn_pargroup = patn_pargroup;
		this.patn_value = patn_value;
		this.patn_prescription = Base64.getEncoder().encodeToString(patn_prescription);
	}

	public PrescriptionOutputmodel() {
		super();
		// TODO Auto-generated constructor stub
	}

}
