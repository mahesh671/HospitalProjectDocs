package spring.orm.services;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spring.orm.contract.AppointmentDao;
import spring.orm.contract.DoctorsDaoTemp;
import spring.orm.contract.PatientDao;
import spring.orm.model.PatientModel;
import spring.orm.model.entity.AppointmentEntity;
import spring.orm.model.input.AppointmentForm;
import spring.orm.model.input.RescheduleAppointmentModel;
import spring.orm.model.output.MailAppOutputModel;
import spring.orm.model.output.RescheduleAppOutput;

@Service
public class AppointmentService {

	@Autowired
	private AppointmentDao apdao;

	@Autowired
	private DoctorsDaoTemp docdao;

	@Autowired
	private PatientDao patdao;

	public List<AppointmentEntity> getAllAppointments() {
		List<AppointmentEntity> alist = apdao.getAllAppointments();
		for (AppointmentEntity a : alist) {
			// Format date
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
			a.setDateFormetted(dateFormat.format(a.getAppn_sch_date()));

			// Format time
			SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
			a.setTimeFormetted(timeFormat.format(a.getAppn_sch_date()));
		}
		return alist;
	}

	public int bookAppointment(AppointmentForm app) {
		// TODO Auto-generated method stub
		DateTimeFormatter sqlformat = DateTimeFormatter.ofPattern("HH:mm:ss");
		System.out.println(LocalTime.parse(app.getSlots(), DateTimeFormatter.ofPattern("hh:mm a")).format(sqlformat));
		int app_id = apdao.bookAppointment(patdao.getPatientById(app.getExistingPatientid()),
				docdao.getdoc(app.getDoctor()),
				app.getAppointmentDate().toString() + " "
						+ LocalTime.parse(app.getSlots(), DateTimeFormatter.ofPattern("hh:mm a")).format(sqlformat),
				app.getAppnrefer(), app.getAppnfee());
		return app_id;
	}

	public RescheduleAppOutput getAppointmentByIdOutput(int app_id) {
		// TODO Auto-generated method stub
		RescheduleAppOutput r = new RescheduleAppOutput();
		AppointmentEntity a = apdao.getAppointmentById(app_id);
		r.setApp_id(a.getAppn_id());
		r.setSlot(a.getAppn_sch_date().toLocalDateTime().toLocalTime());
		r.setApp_sch_date(Date.valueOf(a.getAppn_sch_date().toLocalDateTime().toLocalDate()));
		r.setDoctor(a.getDoctor());
		r.setPatient(a.getPm());

		return r;

	}

	public int bookAppointmentWithNewPatient(AppointmentForm app) {

		PatientModel p = new PatientModel();
		p.setPatn_name(app.getNewPatientName());
		p.setPatn_age(app.getNewPatientAge());
		p.setPatn_bgroup(app.getNewPatientBgroup());
		p.setPatn_rdate(LocalDate.now());
		p.setPatn_gender(app.getNewPatientGender());

		patdao.addNewPatient(p);
		DateTimeFormatter sqlformat = DateTimeFormatter.ofPattern("HH:mm:ss");
		System.out.println("in docdao appointment");
		int app_id = apdao.bookAppointment(p, docdao.getdoc(app.getDoctor()),
				app.getAppointmentDate().toString() + " "
						+ LocalTime.parse(app.getSlots(), DateTimeFormatter.ofPattern("hh:mm a")).format(sqlformat),
				app.getAppnrefer(), app.getAppnfee());
		return app_id;
	}

	public void cancelAppointment(int app_id) {
		// TODO Auto-generated method stub
		apdao.cancelAppointment(app_id);

	}

	public MailAppOutputModel getAppointmentByID(int app_id) {
		// TODO Auto-generated method stub
		AppointmentEntity a = apdao.getAppointmentById(app_id);
		MailAppOutputModel ao = new MailAppOutputModel();
		ao.setAppn_id(a.getAppn_id());
		ao.setDoc_name(a.getDoctor().getDoctName());
		ao.setAppn_booked_Date(a.getAppn_booked_Date());
		ao.setAppn_sch_date(a.getAppn_sch_date());
		ao.setAppn_payamount(a.getAppn_payamount());
		ao.setAppn_paymode(a.getAppn_paymode());
		ao.setDoc_Photo(a.getDoctor().getDoctPhoto());
		ao.setAppn_payreference(a.getAppn_payreference());
		ao.setPat_name(a.getPm().getPatn_name());
		ao.setMail(a.getPm().getUserPass().getMail());
		return ao;

	}
	@Transactional
	public void reschduleAppointment(RescheduleAppointmentModel rm) {
		// TODO Auto-generated method stub
		apdao.reschduleAppointment(rm);

	}
}
