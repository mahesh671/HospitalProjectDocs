package spring.orm.services;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import spring.orm.contract.DCDao;

@Component
public class ReportServices {
	@Autowired
	DCDao dc;

	public String fileUploadMethod(CommonsMultipartFile file, int id) {
		String filepath = null;
		if (!file.isEmpty()) {
			String fileName = file.getOriginalFilename();
			String destinationPath = "C:/Reports/";
			filepath = destinationPath + fileName;
			try {
				Path destinationFilePath = Path.of(destinationPath, fileName);

				// Copy the file to the destination path
				Files.copy(file.getInputStream(), destinationFilePath, StandardCopyOption.REPLACE_EXISTING);

			} catch (IOException e) {
				e.printStackTrace();
				return "error";
			}
		} else {
			return "empty";
		}

		saveFileDetails(id, filepath);

		return "success";

	}

	public void saveFileDetails(int id, String filepath) {

		dc.saveReportInfo(id, filepath);

	}

}