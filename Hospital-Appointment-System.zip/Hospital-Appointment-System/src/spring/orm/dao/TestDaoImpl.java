package spring.orm.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

import spring.orm.contract.TestDao;
import spring.orm.model.testModel;

@Component
public class TestDaoImpl implements TestDao {

	@PersistenceContext
	private EntityManager em;

	@Transactional
	@Override
	public void savetest(testModel s) {

		System.out.println("Inside savetest");
		em.persist(s);
	}

	@Override
	@Transactional
	public List<testModel> gettests() {

		System.out.println("1");
		List<testModel> t = em.createQuery("SELECT t FROM testModel t", testModel.class).getResultList();
		System.out.println("Hello" + t);
		return t;
	}

	@Override
	@Transactional
	public testModel gettestbyid(int id) {

		return em.find(testModel.class, id);
	}

	@Override
	@Transactional
	public void updatetest(testModel t) {

		// testModel s = session.get(testModel.class, test_id);
		// Update the properties of the testModel object

		em.merge(t);
	}

	@Transactional
	@Override
	public void deltest(int test_id) {

		testModel s = em.find(testModel.class, test_id);
		em.remove(s);
	}

	@Transactional
	@Override
	public List<testModel> gettestbycat(String cat) {
		// TODO Auto-generated method stub return
		System.out.println(cat);
		return em.createQuery("select t from testModel t where t.test_category=:cat", testModel.class)
				.setParameter("cat", cat).getResultList();
	}

	@Transactional
	@Override
	public Object gettestprice(int test) {
		// TODO Auto-generated method stub return
		// System.out.println(cat);
		System.out.println(test);
		return em.createQuery("select t.test_price from testModel t where t.test_id=:test").setParameter("test", test)
				.getSingleResult();
	}

	@Override
	public List<testModel> getcat() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getTestCat() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void savetest(String test_name, String test_category, int test_price, String test_method,
			String test_fromrange, String test_torange, String test_status) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Object> getviewtests(int testid) {
		// TODO Auto-generated method stub
		return null;
	}

}
