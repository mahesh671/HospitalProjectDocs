package spring.orm.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import spring.orm.model.entity.PatientMedicalProfile;

@Repository
public class PatientProfileUpdateDAOImpl implements PatientProfileUpdateDAO {

	@PersistenceContext
	private EntityManager em;

	@Transactional
	@Override
	public void save(PatientMedicalProfile pmp) {
		// TODO Auto-generated method stub
		em.persist(pmp);
	}

}
