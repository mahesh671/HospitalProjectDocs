package spring.orm.dao;

import spring.orm.model.entity.PatientMedicalProfile;

public interface PatientProfileUpdateDAO {

	void save(PatientMedicalProfile pmp);

}
