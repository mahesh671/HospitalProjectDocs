package spring.orm.dao;

import java.sql.Timestamp;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

import spring.orm.contract.AppointmentDao;
import spring.orm.model.PatientModel;
import spring.orm.model.entity.AppointmentEntity;
import spring.orm.model.entity.DoctorTemp;
import spring.orm.model.input.BookedAppForm;
import spring.orm.model.input.RescheduleAppointmentModel;
import spring.orm.model.output.OutputBookedAppointmnets;

@Component
public class AppointmentDaoImpl implements AppointmentDao {

	@PersistenceContext
	private EntityManager em;

	@Override
	@Transactional
	public List<Object[]> fetchUpcomingAppointmentData() {

		String hql = "SELECT a.appn_id, d.name, p.patn_name, a.appn_sch_date " + "FROM Appointmentmodel a "
				+ "JOIN a.doctor d " + "JOIN a.pm p " + "WHERE a.appn_sch_date > :date";

		Query q = em.createQuery(hql);

		q.setParameter("date", "2023-06-05");

		List<Object[]> data = q.getResultList();

		for (Object[] x : data) {
			for (Object y : x) {
				System.out.println(y + " ");
			}
			System.out.println();
		}

		return data;
	}

	public List<Object[]> fetchBADDateWise(String from, String to) {
		String hql = "select a.appn_id, d.name, p.patn_name, a.appn_sch_date, a.appn_status "
				+ "from Appointmentmodel a " + "join a.doctor d" + "join a.pm p"
				+ "where date_trunc('day', a.appn_sch_date) between :startDate and :endDate";

		Query q = em.createQuery(hql);

		q.setParameter("startDate", "2023-06-05");

		q.setParameter("endDate", "2023-06-14");

		List<Object[]> data = q.getResultList();

		for (Object[] obj : data) {

			for (Object x : obj) {
				System.out.println(x + " ");
			}
			System.out.println(" ");
		}

		return null;
	}

	public List<Object[]> fetchBADDateSpecWise(String from, String to, String spec) {
		return null;
	}

	public List<Object[]> fetchBADDateSpecActWise(String from, String to, String spec, String act) {
		return null;

	}

	public List<Object[]> fetchBADDateSpecActDocWise(String from, String to, String spec, String act, String doc) {
		return null;

	}

	@Override
	@Transactional
	public List<AppointmentEntity> getAllAppointments() {
		// TODO Auto-generated method stub
		return em.createQuery("select a from AppointmentEntity a", AppointmentEntity.class).getResultList();
	}

	@Override
	@Transactional
	public boolean isSlotBooked(int doc_id, String date, String time) {
		// TODO Auto-generated method stub

		String sch_date = date + " " + time;
		System.out.println(doc_id + " " + sch_date);
		String q = "select a from AppointmentEntity a where a.doctor.id= : doc_id and a.appn_sch_date=:sch_date ";
		Query qu = em.createQuery(q, AppointmentEntity.class);
		qu.setParameter("doc_id", doc_id);
		qu.setParameter("sch_date", Timestamp.valueOf(sch_date));
		List<AppointmentEntity> a = qu.getResultList();
		// AppointmentEntity a = (AppointmentEntity) qu.getSingleResult();
		if (a.size() > 0)
			return true;
		return false;

	}

	@Override
	@Transactional
	public int bookAppointment(PatientModel existingPatientid, DoctorTemp doctor, String bookedDate, String payref,
			double payamount) {
		// TODO Auto-generated method stub
		AppointmentEntity a = new AppointmentEntity();
		a.setDoctor(doctor);
		a.setAppn_booked_Date(new Timestamp(System.currentTimeMillis()));
		a.setPm(existingPatientid);
		a.setAppn_sch_date(Timestamp.valueOf(bookedDate));
		a.setAppn_paymode("CARD");
		a.setAppn_payamount(payamount);
		a.setAppn_payreference(payref);
		a.setAppn_status("YETO");
		em.persist(a);
		return a.getAppn_id();

	}

	@Override
	public AppointmentEntity getAppointmentById(int app_id) {
		// TODO Auto-generated method stub
		return em.find(AppointmentEntity.class, app_id);
	}

	@Override
	@Transactional
	public void cancelAppointment(int app_id) {
		// TODO Auto-generated method stub
		AppointmentEntity a = em.find(AppointmentEntity.class, app_id);
		a.setAppn_status("CNL");
		em.merge(a);

	}

	@Override
	public void reschduleAppointment(RescheduleAppointmentModel rm) {
		// TODO Auto-generated method stub
		AppointmentEntity a = em.find(AppointmentEntity.class, rm.getAppointmentId());
		DateTimeFormatter sqlformat = DateTimeFormatter.ofPattern("HH:mm:ss");
		System.out.println("in docdao appointment");

		a.setAppn_sch_date(Timestamp.valueOf(rm.getRescheduleDate() + " "
				+ LocalTime.parse(rm.getSlot(), DateTimeFormatter.ofPattern("HH:mm a")).format(sqlformat)));
		em.merge(a);

	}

	@Override
	@Transactional
	public List<OutputBookedAppointmnets> fetchBookedAppData(BookedAppForm baf) {

		String hql = "";
		List<OutputBookedAppointmnets> data = null;

		if (baf.getStatus().equals("select") && baf.getDoctor().equals("select")) {

			String spec = baf.getSpec();

			System.out.println(spec);

			hql = "SELECT new spring.orm.model.output.OutputBookedAppointmnets(a.appn_id, p.patn_name, d.doctName, a.appn_sch_date, s.title, a.appn_status)"
					+ "FROM AppointmentEntity a" + " JOIN a.pm p " + " JOIN a.doctor d" + " JOIN d.specialization s"
					+ " WHERE s.title = :val";

			data = em.createQuery(hql, spring.orm.model.output.OutputBookedAppointmnets.class).setParameter("val", spec)
					.getResultList();

		} else if (baf.getSpec().equals("select") && baf.getDoctor().equals("select")) {

			String stat = baf.getStatus();

			String val = "";

			if (stat.equals("Active")) {
				val = "YETO";
			} else if (stat.equals("Inactive")) {
				val = "CMPLD";
			}

			hql = "SELECT new spring.orm.model.output.OutputBookedAppointmnets(a.appn_id, p.patn_name, d.doctName, a.appn_sch_date, s.title, a.appn_status)"
					+ "FROM AppointmentEntity a" + " JOIN a.pm p " + " JOIN a.doctor d" + " JOIN d.specialization s"
					+ " WHERE a.appn_status = :val";
			System.out.println(val);
			data = em.createQuery(hql, spring.orm.model.output.OutputBookedAppointmnets.class).setParameter("val", val)
					.getResultList();

		} else if (baf.getSpec().equals("select") && baf.getStatus().equals("select")) {

			String doc = baf.getDoctor();

			hql = "SELECT new spring.orm.model.output.OutputBookedAppointmnets(a.appn_id, p.patn_name, d.doctName, a.appn_sch_date, s.title, a.appn_status)"
					+ "FROM AppointmentEntity a" + " JOIN a.pm p " + " JOIN a.doctor d" + " JOIN d.specialization s"
					+ " WHERE d.doctName = :val";

			data = em.createQuery(hql, spring.orm.model.output.OutputBookedAppointmnets.class).setParameter("val", doc)
					.getResultList();

		}
		return data;

	}
}