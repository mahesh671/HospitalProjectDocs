package spring.orm.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import spring.orm.contract.PatientDao;
import spring.orm.model.PatientModel;
import spring.orm.model.testModel;
import spring.orm.model.entity.AppointmentEntity;
import spring.orm.model.entity.PatientMedicalProfile;
import spring.orm.model.output.PrescriptionOutputmodel;
import spring.orm.model.output.patientPrescriptionOutputmodel;

@Repository
public class PatientDaoImpl implements PatientDao {
	@PersistenceContext
	private EntityManager em;

	@Override
	@Transactional
	public int savePatient(PatientModel patient) {
		em.persist(patient);
		return patient.getPatn_id();
	}

	@Override
	@Transactional
	public List<Object> getapptestcards() {

		// LocalDate currentDate = LocalDate.now();
		// String d = currentDate.toString();
		String d = "2023-06-05 10:30:00";

		List<AppointmentEntity> lm = em
				.createQuery("select a from AppointmentEntity a where a.appn_sch_date =:d", AppointmentEntity.class)
				.setParameter("d", Timestamp.valueOf(d)).getResultList();
		// return s.get(Specialization.class, Id);
		int app = lm.size();
		System.out.println(app);
		List<testModel> tm = em.createQuery("select t from testModel t ", testModel.class).getResultList();
		int tests = tm.size();
		System.out.println(tests);
		List<Object> ls = new ArrayList<>();

		ls.add(app);
		ls.add(tests);

		return ls;
	}

	@Override
	@Transactional
	public List<PatientModel> getAllPatientModels() {
		// TODO Auto-generated method stub
		return em.createQuery("select p from PatientModel p", PatientModel.class).getResultList();
	}

	@Transactional
	@Override
	public List<patientPrescriptionOutputmodel> getPrescription() {
		String d = "2023-06-05";

		// TODO Auto-generated method stub
		List<patientPrescriptionOutputmodel> lp = em.createQuery(
				"select pmu.lastConsultationDate ,pmu.prescriptionImage ,pmu.nextAppointmentDate,d.doctName,d.doctCfee "
						+ "from PatientProfileUpdate pmu,DoctorTemp d,AppointmentEntity a where pmu.patientId=a.pm.patn_id  and pmu.lastConsultationDate=:d "
						+ "and a.doctor.doctId=d.id " + "and pmu.patientId=:p ")
				.setParameter("d", d).setParameter("p", 1)

				.getResultList();
		return lp;
	}

	@Override
	public PatientModel getPatientById(int existingPatientid) {
		// TODO Auto-generated method stub
		return em.find(PatientModel.class, existingPatientid);
	}

	@Override
	@Transactional
	public int addNewPatient(PatientModel p) {
		// TODO Auto-generated method stub
		em.persist(p);

		return p.getPatn_id();
	}

	@Override
	public List<Object> getapptests() {

		List<Object> lm3 = em.createQuery(
				"select d.id.dgbltestId,t.test_name from Diagnostictestbill d , testModel t,DiagnosticBillModel d1 where d.id.dgblId=d1.dgbl_id and d.id.dgbltestId=t.test_id and d1.dgbl_patn_id=:p ")
				.setParameter("p", 2).getResultList();

		return lm3;
	}

	@Override
	public List<Object> getapps() {
		List<Object> lm2 = em.createQuery(
				"SELECT a.appn_id, d.doctName, a.appn_sch_date, a.appn_status FROM AppointmentEntity a JOIN a.doctor d WHERE a.pm.patn_id = :p")
				.setParameter("p", 1).getResultList();
		return lm2;
	}

	@Override
	@Transactional
	public List<PatientMedicalProfile> getParaGroup() {

		List<PatientMedicalProfile> lp = em.createQuery("select pp "
				+ "from PatientMedicalProfile pp,AppointmentEntity a where pp.id.patn_id=a.pm.patn_id and pp.id.patn_id=:p ",PatientMedicalProfile.class)
				.setParameter("p", 4)

				.getResultList();
		return lp;
	}

	@Override
	@Transactional
	public List<PrescriptionOutputmodel> getallPrescription(int id) {

		String hql = "select new spring.orm.model.output.PrescriptionOutputmodel(p.patn_parameter,p.patn_pargroup,p.patn_value,p.patn_prescription) "
				+ "from PatientMedicalProfile p where p.id.patn_id=:p ";
		List<PrescriptionOutputmodel> lp = em.createQuery(hql, spring.orm.model.output.PrescriptionOutputmodel.class)
				.setParameter("p", id)

				.getResultList();
		return lp;
	}

	@Override
	public List<Integer> getAllappnids(int patn_id) {
		// TODO Auto-generated method stub
		List<Integer> lp3 = new ArrayList<>();
		List<Integer> lp2 = new ArrayList<>(Collections.nCopies(10000, null));
		List<Integer> lp = em
				.createQuery("select a.appn_id " + "from AppointmentEntity a where a.pm.patn_id=:patn_id  ")
				.setParameter("patn_id", patn_id)

				.getResultList();

		lp2 = em.createQuery("select a.appn_id "
				+ "from PatientMedicalProfile pmp,AppointmentEntity a where pmp.id.patn_id<>:patn_id or pmp.id.patn_appn_id <>a.appn_id ")
				.setParameter("patn_id", patn_id)

				.getResultList();

		return lp2;
	}

	@Override
	@Transactional
	public List<Integer> getAllPatientids() {
		// TODO Auto-generated method stub
		return em.createQuery("select p.patn_id from PatientModel p").getResultList();
	}

}
