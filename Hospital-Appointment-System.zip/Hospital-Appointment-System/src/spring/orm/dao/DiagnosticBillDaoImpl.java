package spring.orm.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import spring.orm.contract.DiagnosticBillDao;
import spring.orm.contract.PatientDao;
import spring.orm.contract.TestDao;
import spring.orm.model.DiagnosticBillModel;
import spring.orm.model.DiagnosticBillModelId;
import spring.orm.model.Diagnostictestbill;
import spring.orm.model.TestBookStatusComposite;
import spring.orm.model.entity.TestBookStatus;
import spring.orm.model.input.BillInputModel;
import spring.orm.model.output.BookedTestIDs;

@Repository
public class DiagnosticBillDaoImpl implements DiagnosticBillDao {

	@PersistenceContext
	private EntityManager em;

	@Autowired
	private PatientDao pd;

	@Autowired
	private TestDao td;

	public List<DiagnosticBillModel> getdbilldetails() {
		return em.createQuery("SELECT d FROM diagnosticBillModel d", DiagnosticBillModel.class).getResultList();
	}

	TestBookStatus st = new TestBookStatus();
	Object d;
	Object p11;
	LocalDate currentDate = LocalDate.now();
	String c = currentDate.toString();
	ArrayList<Object> al = new ArrayList();
	ArrayList<Object> al3 = new ArrayList();

	List<Integer> testi = new ArrayList<>();
	String con;
	BookedTestIDs btid = new BookedTestIDs(testi, con);

	@Transactional
	public void booktestt(BillInputModel bi) {

		System.out.println("inside ne");

		int test = bi.getTest();
		String type = bi.getType();
		String contact = bi.getContact();

		System.out.println(test);
		testi.add(test);
		System.out.println(testi);
		System.out.println("Length" + "" + testi.size());
		int patn_id = (int) em.createQuery("select p.patn_id from PatientModel p where p.patn_contact=:contact")
				.setParameter("contact", contact).getSingleResult();
		System.out.println(patn_id);
		System.out.println("in 1");
		TestBookStatusComposite id = new TestBookStatusComposite();
		id.setTbPatnId(patn_id);
		id.setTestId(test);

		st.setType(type);
		st.setId(id);
		st.setBookedDate(currentDate);
		st.setStatus("pending");

		em.persist(st);

	}

	@Transactional
	public List<Object> gettotalbills(String contact) {

		List<Object> tests1 = new ArrayList<>();
		List<Object> tests2 = new ArrayList<>();
		int amt = 0;

		int patn_id = (int) em.createQuery("select p.patn_id from PatientModel p where p.patn_contact=:contact")
				.setParameter("contact", contact).getSingleResult();
		if (patn_id >= 0) {

			List<Integer> testh = (List<Integer>) em.createQuery(
					"select t.id.test_id  from TestBookStatus t where t.id.tb_patn_id=:patn_id and t.status= 'pending'")
					.setParameter("patn_id", patn_id).getResultList();
			System.out.println("length here" + testh.size());
			for (int i = 0; i < testh.size(); i++) {
				int j = (int) testh.get(i);

				tests1 = em
						.createQuery("SELECT t.test_name, t.test_method, t.test_price "
								+ "FROM testModel t, TestBookStatus tb " + "WHERE t.test_id = :testId "
								+ "AND tb.status = 'pending' " + "AND tb.id.test_id = t.test_id")
						.setParameter("testId", j).getResultList();

				int testsprice = (int) em.createQuery("select t.test_price from testModel t where t.test_id=:j ")
						.setParameter("j", j).getSingleResult();

				amt = amt + testsprice;
				System.out.println(amt);
				tests2.add(tests1);

			}
			tests2.add(amt);
			btid.setAmt(amt);

		}

		return tests2;

	}

	@Transactional
	public void storedb(String contact) {
		int patn_id = (int) em.createQuery("select p.patn_id from PatientModel p where p.patn_contact=:contact")
				.setParameter("contact", contact).getSingleResult();
		String type = (String) em.createQuery("select t.type from TestBookStatus t  where t.id.tb_patn_id=:patn_id")
				.setMaxResults(1).setParameter("patn_id", patn_id).getSingleResult();

		if (patn_id >= 0) {

			int price = btid.getAmt();

			List<Integer> t1 = btid.getTestids();

			DiagnosticBillModel d1 = new DiagnosticBillModel((Integer) patn_id, c, price, type);
			System.out.println("in 2");
			em.persist(d1);

			for (int i = 0; i < t1.size(); i++) {

				int price2 = (int) em.createQuery("select t.test_price from testModel t where t.test_id=:j ")
						.setParameter("j", t1.get(i)).getSingleResult();
				DiagnosticBillModelId id = new DiagnosticBillModelId((Integer) d1.getDgbl_id(), t1.get(i));
				System.out.println("in 3");
				Diagnostictestbill d2 = new Diagnostictestbill(id, price2);
				System.out.println("in 4");
				em.persist(d2);

				TestBookStatusComposite comid = new TestBookStatusComposite();
				comid.setTbPatnId(patn_id);
				comid.setTestId(t1.get(i));

				TestBookStatus st = new TestBookStatus();
				st.setId(comid);
				st.setBookedDate(currentDate);
				st.setStatus("paid");

				em.merge(st);

			}

		}

	}



	@Override
	public List<Object> getunpaidbills(String contact) {
		// TODO Auto-generated method stub

		return null;
	}



	@Override
	public List<String> gettestdate(String date1, String date2) {
		// TODO Auto-generated method stub
		return null;
	}

}