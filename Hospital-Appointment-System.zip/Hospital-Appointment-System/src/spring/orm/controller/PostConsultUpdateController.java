package spring.orm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.google.gson.Gson;

import spring.orm.contract.PatientDao;
import spring.orm.model.entity.PatientMedicalProfile;
import spring.orm.model.output.PrescriptionOutputmodel;
import spring.orm.model.output.patientPrescriptionOutputmodel;

@Controller
public class PostConsultUpdateController {

	@Autowired
	private PatientDao pdao;

	@RequestMapping(value = "/getapptests", method = RequestMethod.GET)
	public ResponseEntity<String> getapptests() {
		List<Object> lo = pdao.getapptests();
		return ResponseEntity.status(HttpStatus.OK).body(new Gson().toJson(lo));
		// return "patient/myprofile";
	}

	@RequestMapping(value = "/getapps", method = RequestMethod.GET)
	public ResponseEntity<String> getapps() {
		List<Object> lo = pdao.getapps();
		return ResponseEntity.status(HttpStatus.OK).body(new Gson().toJson(lo));
		// return "patient/myprofile";
	}

	@RequestMapping(value = "/getParaGroup", method = RequestMethod.GET)
	public ResponseEntity<String> getParaGroup() {
		List<PatientMedicalProfile> lo = pdao.getParaGroup();
		return ResponseEntity.status(HttpStatus.OK).body(new Gson().toJson(lo));
		// return "patient/myprofile";
	}

	@RequestMapping(value = "/getPrescription", method = RequestMethod.GET)
	public ResponseEntity<String> getPrescription() {
		List<patientPrescriptionOutputmodel> lo = pdao.getPrescription();
		return ResponseEntity.status(HttpStatus.OK).body(new Gson().toJson(lo));
		// return "patient/myprofile";
	}

	@RequestMapping(value = "/getallPrescription", method = RequestMethod.GET)
	public String getallPrescription(Model model) {

		List<PrescriptionOutputmodel> lm = pdao.getallPrescription(20);
		model.addAttribute("pres", lm);
		System.out.println(lm.toString());
		return "patient/patpresdisplay";
	}

}
