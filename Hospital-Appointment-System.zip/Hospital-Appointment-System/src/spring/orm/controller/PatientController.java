package spring.orm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;

import spring.orm.contract.DiagnosticBillDao;
import spring.orm.contract.DocScheduleDao;
import spring.orm.contract.DoctorsDaoTemp;
import spring.orm.contract.PatientDao;
import spring.orm.contract.SpecializationDao;
import spring.orm.contract.TestDao;
import spring.orm.contract.UserDao;
import spring.orm.model.Specialization;
import spring.orm.model.testModel;
import spring.orm.services.DoctorOutputService;
import spring.orm.util.PatientSession;

@Controller
@RequestMapping("/patient")
public class PatientController {
	@Autowired
	private SpecializationDao specdao;

	@Autowired
	private DoctorsDaoTemp docdao;
	@Autowired
	private PatientDao pdao;

	@Autowired
	private UserDao udao;
	@Autowired
	private TestDao tdao;
	@Autowired
	private DiagnosticBillDao dbo;

	@Autowired

	private DoctorOutputService docserv;
	@Autowired
	private DocScheduleDao docschdao;
	PatientSession ps;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String basePage() {
		return "patient/patient";
	}

	@RequestMapping(value = "/profile", method = RequestMethod.GET)
	public String viewProfile() {

		return "patient/profile";
	}

	@RequestMapping(value = "/patienttest", method = RequestMethod.GET)
	public String ptest(Model model) {
		List<testModel> tm = tdao.gettests();
		Gson gson = new Gson();
		String json = gson.toJson(tm);
		model.addAttribute("tests", json);
		return "patient/patienttest";
	}

	@RequestMapping(value = "/appointment", method = RequestMethod.GET)
	public String getappPage(Model m) {
		List<Specialization> speclist = specdao.getAllSpec();
		m.addAttribute("speclist", speclist);

		return "patient/appointment";
	}

	@RequestMapping(value = "/gettestbydate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<String> gettestbydate(@RequestParam String date1, @RequestParam String date2,
			Model model) {
		System.out.println("in gettest");
		List<String> lm = dbo.gettestdate(date1, date2);
		Gson gson = new Gson();
		String json = gson.toJson(lm);
		model.addAttribute("testfiltered", json);
		return lm;
	}

	@RequestMapping(value = "/myfamily", method = RequestMethod.GET)
	public String viewMyprofile() {
		return "patient/myfamily";
	}

	@RequestMapping(value = "/getapptestcards", method = RequestMethod.GET)
	public ResponseEntity<String> getapptestcards() {
		List<Object> lo = pdao.getapptestcards();
		return ResponseEntity.status(HttpStatus.OK).body(new Gson().toJson(lo));
		// return "patient/myprofile";
	}

	@RequestMapping(value = "/getTestDetails", method = RequestMethod.POST)
	public ResponseEntity<Object> getTestDetails(@RequestParam int testid) {
		List<Object> lo = tdao.getviewtests(testid);
		return ResponseEntity.status(HttpStatus.OK).body(new Gson().toJson(lo));

	}

}
