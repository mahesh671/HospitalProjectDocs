package spring.orm.controller;

import java.sql.Timestamp;
import java.time.LocalTime;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import spring.orm.model.PatientModel;
import spring.orm.model.UserPass;
import spring.orm.model.input.RegistrationForm;
import spring.orm.services.RegistrationService;
import spring.orm.services.UserServices;
import spring.orm.util.MailSend;
import spring.orm.util.PatientSession;

@Controller

public class LoginController {
	private static final String ROLE_ADMINISTRATOR = "ADMIN";
	private static final String ROLE_PATIENT = "Patient";
	private static final String ROLE_DIAGNOSTIC_CENTER = "DCADMIN";

	private boolean isExpired;
	private String otp;

	private final UserServices userService;

	private final RegistrationService rs;

	@Autowired
	public LoginController(UserServices userService, RegistrationService rs) {
		this.userService = userService;
		this.rs = rs;
	}

	@RequestMapping(value = "/")
	public String dcscreen() {
		return "login/home";
	}

	@RequestMapping(value = "/forget", method = RequestMethod.GET)
	public String getForgetPage() {
		return "login/forgetPage";
	}

	@RequestMapping(value = { "admin/change", "dcadmin/change", "patient/change" }, method = RequestMethod.GET)
	public String getChangePage() {
		return "login/changepass";
	}

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String getRegisterPage() {
		return "login/registerPage";
	}

	@RequestMapping(value = "/forgetVal", method = RequestMethod.POST)
	public String sendMail(@RequestParam String uname) {
		MailSend mailSender = new MailSend();
		UserPass user = userService.getUser(uname);
		String userEmail = user.getMail();
		otp = mailSender.generateOTP();
		mailSender.sendOTPMail(userEmail, otp);

		LocalTime currentTime = LocalTime.now();
		Timestamp otpTimestamp = Timestamp.valueOf(java.time.LocalDate.now() + " " + currentTime);
		String otpTimestampString = otpTimestamp.toString();

		user.setOtp(otp);
		isExpired = userService.saveUser(otpTimestampString, 3);

		return "login/reset";
	}

	@RequestMapping(value = "/passwordset", method = RequestMethod.POST)
	public String otpValidate(@RequestParam String lcpass, @RequestParam String lotp, @RequestParam String uname) {
		UserPass user = userService.getUser(uname);
		if (isExpired && lotp.equals(otp)) {
			userService.updateUser(lcpass, uname);
			user.setPassword(lcpass);
			return "login/success";
		} else {
			System.out.println("OTP Expired");
			// Handle OTP expired scenario
			return "login/otpExpired";
		}
	}

	@RequestMapping(value = "/passwordchange", method = RequestMethod.POST)
	public String passwordChange(@RequestParam String lcpass, @RequestParam String opass, @RequestParam String uname) {
		UserPass user = userService.getUser(uname);
		if (user.getPassword().equals(opass)) {
			user.setPassword(lcpass);
			userService.changeUser(lcpass, uname);
			return "login/success";
		} else {
			System.out.println("Wrong Old Password");
			// Handle wrong old password scenario
			return "login/changepass";
		}
	}

	@RequestMapping(value = "/saveregister", method = RequestMethod.POST)
	public String saveRegister(@ModelAttribute RegistrationForm rf, Model model) {
		rs.registerPatient(rf);
		return "redirect:/";
	}

	@RequestMapping(value = "/checkUsernameAvailability", method = RequestMethod.GET)
	@ResponseBody
	public String checkUsernameAvailability(@RequestParam String username) {
		System.out.println("in check");
		boolean isUsernameAvailable = userService.isUsernameAvailable(username);

		if (isUsernameAvailable) {
			return "available";
		} else {
			return "taken";
		}
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String redirectToDashboard(@RequestParam("uname") String uname, @RequestParam("pass") String pass,
			HttpSession session, Model model) {
		UserPass user = userService.getUser(uname);
		if (user != null && user.getPassword().equals(pass)) {
			String role = user.getRole();
			switch (role) {
			case ROLE_ADMINISTRATOR:
				// Redirect to administrator dashboard
				return "redirect:/admin/";
			case ROLE_PATIENT:
				PatientModel patientModel = userService.getPatientDetails(user.getPatient().getPatn_id());
				if (patientModel != null) {

					// Create and store patient session
					PatientSession patientSession = new PatientSession();
					patientSession.setId(patientModel.getPatn_id());
					patientSession.setUsername(user.getUsername());
					patientSession.setName(patientModel.getPatn_name());
					patientSession.setAge(patientModel.getPatn_age());
					patientSession.setGender(patientModel.getPatn_gender().charAt(0));
					patientSession.setAccessPatientId(patientModel.getAccessPatientId());
					patientSession.setBloodGroup(patientModel.getPatn_bgroup());
					patientSession.setRegistrationDate(patientModel.getPatn_rdate());
					patientSession.setLastVisitDate(patientModel.getPatn_lastvisit());
					// patientSession.setLastAppointmentId(patientModel.getPatn_lastapp_id());

					// Set other relevant data in the patient session
					// ...

					// Store patient session in the HttpSession
					session.setAttribute("patientSession", patientSession);
					// Redirect to patient dashboard
					return "redirect:/patient/";
				}
			case ROLE_DIAGNOSTIC_CENTER:
				// Redirect to diagnostic center dashboard
				return "redirect:/dcadmin/";
			}
		}
		model.addAttribute("error", "Incorrect username or password");
		return "login/home";
	}
}