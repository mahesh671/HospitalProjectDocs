package spring.orm.contract;

import java.util.List;
import java.util.Map;

import spring.orm.model.DiagnosticBillModel;
import spring.orm.model.input.BillInputModel;

public interface DiagnosticBillDao {
	public List<DiagnosticBillModel> getdbilldetails();



	public void booktestt(BillInputModel bi);

	public List<Object> gettotalbills(String contact);

	public void storedb(String contact);

	public List<Object> getunpaidbills(String contact);


	public List<String> gettestdate(String date1, String date2);

}