package spring.orm.contract;


import spring.orm.model.DoctorSchedule;

public interface DocScheduleDao {

	public DoctorSchedule getSchedulebyId(int id);


}
