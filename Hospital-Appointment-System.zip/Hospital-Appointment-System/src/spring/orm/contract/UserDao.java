package spring.orm.contract;

import java.util.List;

import spring.orm.model.DiagnosticBillModel;
import spring.orm.model.Doctor;
import spring.orm.model.PatientModel;
import spring.orm.model.Specialization;
import spring.orm.model.UserPass;
import spring.orm.model.testModel;
import spring.orm.model.entity.AppointmentEntity;

public interface UserDao {
	public UserPass getUserDetails(String s);

	public boolean saveUser(String ottps, int time);

	public void updateUser(String lcpass, String uname);

	public void changeUser(String lcpass, String uname);

	public void registeruser(String name, String pass, String mail, String role);

	public List<Doctor> getdocspecdetails();

	public void savedoc(String doc_name, String doc_qual, int spec_id, String doc_exp, byte[] doc_photo, int doc_cfee);

	public void savetest(String test_name, String test_category, int test_price, String test_method,
			String test_fromrange, String test_torange, String test_status);

	public List<testModel> gettests();

	public List<AppointmentEntity> getapppaymnets();

	public List<Specialization> getpecdetails();

	public List<DiagnosticBillModel> getdbilldetails();

	public testModel gettestbyid(int id);

	public void updatetest(int test_id, String test_name, String test_category, int test_price, String test_method,
			String test_fromrange, String test_torange);

	public void deltest(int test_id);

	public void booktest(String id);

	public List<testModel> getcat();

	public List<testModel> gettestbycat(String cat);

	public List<String> getTestCat();

	public Integer gettestprice(String test);

	public List<AppointmentEntity> getspecPayments(String spec);

	public List<AppointmentEntity> getspecdatewisepay(String spec, String date, String date1);

	public List<AppointmentEntity> getdatewisepay(String date, String date2);

	public List<AppointmentEntity> getdocwisepay(int doc);

	public List<AppointmentEntity> getdocdatewisepay(int doc, String dat, String date);

	public void saveUser(UserPass user);

	public PatientModel getPatientDetails(Integer patn_id);

}