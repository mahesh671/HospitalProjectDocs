package spring.orm.contract;

import java.util.List;

import spring.orm.model.PatientModel;
import spring.orm.model.entity.PatientMedicalProfile;
import spring.orm.model.output.PrescriptionOutputmodel;
import spring.orm.model.output.patientPrescriptionOutputmodel;

public interface PatientDao {
	public List<Object> getapptestcards();

	public List<PatientModel> getAllPatientModels();

	public List<patientPrescriptionOutputmodel> getPrescription();

	public PatientModel getPatientById(int existingPatientid);

	public int addNewPatient(PatientModel p);

	public List<PatientMedicalProfile> getParaGroup();

	public int savePatient(PatientModel patient);

	public List<Object> getapptests();

	public List<Object> getapps();

	List<Integer> getAllPatientids();

	public List<Integer> getAllappnids(int patn_id);

	List<PrescriptionOutputmodel> getallPrescription(int id);

}
