package spring.orm.contract;

import java.util.List;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import spring.orm.model.entity.DoctorTemp;
import spring.orm.model.input.DoctorInput;
import spring.orm.model.output.DoctorListOutput;
import spring.orm.model.output.DoctorOutPutModel;

public interface DoctorsDaoTemp {
	public List<DoctorTemp> findAll();

	public DoctorTemp getdoc(int Id);

	public void updatedoc(DoctorTemp d);

	void saveDoc(DoctorTemp s);

	public List<DoctorOutPutModel> getallDocScheduleBySpec(String spec);

	public DoctorOutPutModel getDocById(int id);

	public List<DoctorOutPutModel> getallDocSchedule();

	public void updatedoc(DoctorInput d, CommonsMultipartFile docphoto);

	public List<DoctorTemp> getAllDoc();

	
}
