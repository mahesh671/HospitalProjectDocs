package spring.orm.contract.services;

public interface TestService {

}