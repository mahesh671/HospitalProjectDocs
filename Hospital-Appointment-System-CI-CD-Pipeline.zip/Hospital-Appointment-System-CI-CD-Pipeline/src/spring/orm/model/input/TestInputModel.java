package spring.orm.model.input;

public class TestInputModel {

	private Integer test_id;

	private String test_name;

	private String test_category;

	private Integer test_price;

	private String test_method;

	private String test_fromrange;
	private String test_torange;

	public int getTest_id() {
		return test_id;
	}

	public void setTest_id(Integer test_id) {
		this.test_id = test_id;
	}

	public String getTest_name() {
		return test_name;
	}

	public void setTest_name(String test_name) {
		this.test_name = test_name;
	}

	public String getTest_category() {
		return test_category;
	}

	public void setTest_category(String test_category) {
		this.test_category = test_category;
	}

	public int getTest_price() {
		return test_price;
	}

	public void setTest_price(Integer test_price) {
		this.test_price = test_price;
	}

	public String getTest_method() {
		return test_method;
	}

	public void setTest_method(String test_method) {
		this.test_method = test_method;
	}

	public String getTest_fromrange() {
		return test_fromrange;
	}

	public void setTest_fromrange(String test_fromrange) {
		this.test_fromrange = test_fromrange;
	}

	public String getTest_torange() {
		return test_torange;
	}

	public void setTest_torange(String test_torange) {
		this.test_torange = test_torange;
	}

}
