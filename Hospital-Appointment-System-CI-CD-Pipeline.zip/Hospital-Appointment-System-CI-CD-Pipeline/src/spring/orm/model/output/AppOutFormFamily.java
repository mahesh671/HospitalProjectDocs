package spring.orm.model.output;

public class AppOutFormFamily {

	private int fam_patni_id;

	private String fam_patn_name;

	public int getFam_patni_id() {
		return fam_patni_id;
	}

	public void setFam_patni_id(int fam_patni_id) {
		this.fam_patni_id = fam_patni_id;
	}

	public String getFam_patn_name() {
		return fam_patn_name;
	}

	public void setFam_patn_name(String fam_patn_name) {
		this.fam_patn_name = fam_patn_name;
	}

}
